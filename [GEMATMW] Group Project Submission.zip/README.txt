=========================================================
Adi's Minigames - GEMATMW Group Project (S15)
Ms. April Say-Awen

AUTHORS:
ADRIEL ISAIAH V. AMOGUIS
BENEDICT C. SUN
GIANCARLO T. TEE
KYLE FRANCIS Y. LIM

=========================================================

This program is mainly designed for a WINDOWS DEVICE, despite the inclusion of a UNIX
executable.

The program has thoroughly been tested and debugged for Windows. Running it using another
operating system or kernel may have unpredictable behavior.

1. Watch the project demo in Canvas studio via the link:
https://dlsu.instructuremedia.com/embed/2f27c52a-a5cc-4e88-897f-3a6f1fdfe008

2. Open the 'EXECUTABLES' folder and run the Windows executable.

3. Play the game!

4. Note that two files will be generated upon running Lakwatsa sa Maynila:
	- playingGrid.txt <-- this file contains the text file of the playing grid
	- randomizer.state <-- this file contains the state of the randomizer

5. Have fun!

6. Logic and Game Theory are discussed in the documentation.